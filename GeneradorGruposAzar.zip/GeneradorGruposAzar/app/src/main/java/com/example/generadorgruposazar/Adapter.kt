package com.example.generadorgruposazar

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.generadorgruposazar.databinding.HolderBinding

class Adapter(val lista:ArrayList<String>):RecyclerView.Adapter<Adapter.Holder>() {
    class Holder(val binding: HolderBinding):RecyclerView.ViewHolder(binding.root){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {

        val binding=HolderBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return Holder(binding)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {

        holder.binding.textView1.text=lista[position]
    }

    override fun getItemCount(): Int {

        return lista.size
    }


}