package com.example.generadorgruposazar

import androidx.lifecycle.ViewModel

class ListaClase:ViewModel() {

    val lista = arrayListOf<String>("JOHAN ",
        "ALAMO ",
        "Camino",
        "ASTRID",
        "JUAN DEL CAMPO",
        "ALBERTO",
        "DANIEL",
        "IKER",
        "DIEGO ",
        "SEBASTIAN ",
        "GUTIERREZ",
        "BRYAN",
        "ANGEL",
        "LUQUERO",
        "ARROYO",
        "RAFA",
        "ISLA",
        "PORTILLA",
        "CARRIZO",
        "VICTOR",
        "TAUSTE",
        "VALVERDE",
        "DAVID",
        "VILLALOBOS")

    fun add(nombre: String){
        lista.add(nombre)
    }

    fun grupos(): List<List<String>>{
        lista.shuffle()
        return lista.chunked(4)
    }



}