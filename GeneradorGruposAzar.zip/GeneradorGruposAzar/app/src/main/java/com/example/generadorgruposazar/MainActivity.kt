package com.example.generadorgruposazar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.marginLeft
import androidx.core.view.setPadding
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.generadorgruposazar.databinding.ActivityMainBinding
//si te da error la linea 11 borrala y vuelve a poner

class MainActivity : AppCompatActivity() {
private lateinit var binding: ActivityMainBinding


    private val viewModel: ListaClase by lazy {
        ViewModelProvider(this)[ListaClase::class.java]

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.list.layoutManager=LinearLayoutManager(this)
        binding.list.adapter=Adapter(viewModel.lista)
        binding.btn1.setOnClickListener {

                val txt1=findViewById<TextView>(R.id.txt1)
                 val nombre=txt1.text.toString()
                viewModel.add(nombre)
                Toast.makeText(this, "alumnos añadido",Toast.LENGTH_LONG).show()
                Log.i("Lista","${viewModel.lista}")
        }

        binding.btn2.setOnClickListener {
            val resultado= viewModel.grupos()
            val Rfinal= resultado.toTypedArray()
//            for (nombre in Rfinal){
//                Log.i("Hola",nombre.toString())
//            }
            val vista=TextView(this)
            vista.append(resultado.toString())
            vista.setPadding(5)
            AlertDialog.Builder(this)
                .setView(vista)
                .setTitle("Grupos")
                .create().show()

        }





    }
}